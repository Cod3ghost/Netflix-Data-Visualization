# Load necessary libraries
library(ggplot2)
library(readr)

# Load the cleaned dataset
netflix_data <- read_csv("Netflix_shows_movies_cleaned.csv")

# Count the top 10 genres
top_genres <- netflix_data %>%
  count(listed_in, sort = TRUE) %>%
  top_n(10)

# Create a bar chart for the top 10 genres
ggplot(top_genres, aes(x = reorder(listed_in, n), y = n)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  coord_flip() +
  labs(title = "Top 10 Most Common Genres", x = "Genre", y = "Number of Shows/Movies")
